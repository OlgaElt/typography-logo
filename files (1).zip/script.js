/* ============================================================
   ТИПОГРАФИЧЕСКИЙ БРИФ — логика приложения
   Статическое приложение, без сервера и базы данных.
   ============================================================ */

"use strict";

/* ---------- Вопросы интервью ----------
   key      — совпадает с полем в company.fit
   q        — текст вопроса (реплика студента-дизайнера)
   pick     — сколько ответов выбрать (по умолчанию 1)
   briefKey — подпись в итоговом брифе                       */
const QUESTIONS = [
  { key: "character", q: "Какой характер должен передавать логотип?", briefKey: "Характер" },
  { key: "style",     q: "Какой стиль типографики вам нравится?",     briefKey: "Стиль" },
  { key: "fontType",  q: "Какой тип шрифта вам ближе?",               briefKey: "Тип шрифта" },
  { key: "tracking",  q: "Как должно выглядеть расстояние между буквами?", briefKey: "Трекинг" },
  { key: "custom",    q: "Нужно ли изменять буквы?",                  briefKey: "Кастомизация" },
  { key: "avoid",     q: "Что точно не подходит?",                    briefKey: "Ограничения", pick: 2 }
];

const MIN_QUESTIONS = 5; // после скольких вопросов можно сформировать бриф

/* ---------- Состояние ---------- */
let company = null;       // выбранная компания
let answered = {};        // { questionKey: [выбранные ответы] }
let started = false;

/* ---------- DOM ---------- */
const elMessages = document.getElementById("messages");
const elChips    = document.getElementById("chips");
const elHint     = document.getElementById("composerHint");
const elAvatar   = document.getElementById("avatar");
const elName     = document.getElementById("clientName");
const elStatus   = document.getElementById("clientStatus");
const elProgWrap = document.getElementById("progressWrap");
const elProgFill = document.getElementById("progressFill");
const elProgCount= document.getElementById("progressCount");

/* ---------- Утилиты ---------- */
const rand   = (arr) => arr[Math.floor(Math.random() * arr.length)];
const sample = (arr, n) => {
  const copy = arr.slice();
  const out = [];
  while (copy.length && out.length < n) out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  return out;
};
const scrollDown = () => { elMessages.scrollTop = elMessages.scrollHeight; };

/* ---------- Сообщения ---------- */
function addMessage(side, html, who) {
  const row = document.createElement("div");
  row.className = "row " + side;
  const bubble = document.createElement("div");
  bubble.className = "bubble " + side;
  bubble.innerHTML = (who ? `<span class="who">${who}</span>` : "") + html;
  row.appendChild(bubble);
  elMessages.appendChild(row);
  scrollDown();
  return row;
}

function addSysnote(text) {
  const note = document.createElement("div");
  note.className = "sysnote";
  note.textContent = text;
  elMessages.appendChild(note);
  scrollDown();
}

function showTyping() {
  const row = document.createElement("div");
  row.className = "row client";
  row.innerHTML = `<div class="bubble client"><div class="typing"><span></span><span></span><span></span></div></div>`;
  elMessages.appendChild(row);
  scrollDown();
  return row;
}

/* реплика заказчика с «печатает…» */
function clientSays(html, who, delay = 650) {
  const typing = showTyping();
  return new Promise((resolve) => {
    setTimeout(() => {
      typing.remove();
      addMessage("client", html, who || company.name);
      resolve();
    }, delay);
  });
}

/* ---------- Чипы ---------- */
function clearChips() { elChips.innerHTML = ""; }

function makeChip(label, onClick, variant) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "chip" + (variant ? " chip--" + variant : "");
  b.textContent = label;
  b.addEventListener("click", onClick);
  elChips.appendChild(b);
  return b;
}

/* ---------- Прогресс ---------- */
function updateProgress() {
  const done = Object.keys(answered).length;
  const total = QUESTIONS.length;
  elProgFill.style.width = (done / total * 100) + "%";
  elProgCount.textContent = done + " / " + total;
}

/* ============================================================
   СТАРТ
   ============================================================ */
function bootIntro() {
  elName.textContent = "Заказчик";
  elStatus.textContent = "на связи";
  elAvatar.textContent = "?";
  addMessage(
    "client",
    "Здравствуйте! Мне нужен текстовый логотип для моей компании. Помогите определить подходящий стиль шрифта.",
    "Заказчик"
  );
  elHint.textContent = "Готовы начать?";
  clearChips();
  makeChip("Начать интервью", startInterview, "primary");
}

function startInterview() {
  started = true;
  company = rand(COMPANIES);
  answered = {};

  // обновляем шапку под выбранную компанию
  elAvatar.textContent = company.name.trim().charAt(0).toUpperCase();
  elName.textContent = company.name;
  elStatus.textContent = company.sphere;
  elProgWrap.hidden = false;
  updateProgress();

  addSysnote("Заказчик найден — компания подобрана случайно");

  clientSays(
    `Меня представляет компания «${company.name}». ${company.desc} Задавайте вопросы — отвечу по сути.`,
    company.name,
    500
  ).then(renderQuestionChips);
}

/* ---------- Список вопросов ---------- */
function renderQuestionChips() {
  clearChips();
  const remaining = QUESTIONS.filter((q) => !answered[q.key]);
  const doneCount = Object.keys(answered).length;

  if (remaining.length) {
    elHint.textContent = "Выберите вопрос — заказчик ответит";
  } else {
    elHint.textContent = "Все вопросы заданы. Можно формировать бриф.";
  }

  QUESTIONS.forEach((q) => {
    const chip = makeChip(q.q, () => askQuestion(q));
    if (answered[q.key]) chip.disabled = true;
  });

  // кнопка завершения — доступна после MIN_QUESTIONS
  if (doneCount >= MIN_QUESTIONS) {
    makeChip("Сформировать бриф", buildBrief, "primary");
  }
}

/* ---------- Один вопрос ---------- */
function askQuestion(q) {
  if (answered[q.key]) return;

  // реплика студента
  addMessage("student", q.q, "Вы");

  // ответ заказчика: случайно из подходящих вариантов компании
  const pool = company.fit[q.key] || [];
  const picked = q.pick && q.pick > 1 ? sample(pool, Math.min(q.pick, pool.length)) : [rand(pool)];
  answered[q.key] = picked;
  updateProgress();

  // блокируем заданный вопрос сразу
  clearChips();
  elHint.textContent = "Заказчик отвечает…";

  const tags = picked.map((p) => `<span class="answer-tag">${p}</span>`).join(" ");
  const lead = clientReplyLead(q.key);

  clientSays(`${lead} ${tags}`, company.name, 600).then(() => {
    const doneCount = Object.keys(answered).length;
    if (doneCount >= QUESTIONS.length) {
      addSysnote("Все пункты собраны");
    }
    renderQuestionChips();
  });
}

/* небольшая вариативность в формулировке ответа заказчика */
function clientReplyLead(key) {
  const leads = {
    character:  ["Характер вижу так:", "Хочется передать:", "По настроению —"],
    style:      ["По стилю мне ближе:", "Нравится направление:", "Стиль —"],
    fontType:   ["По типу шрифта:", "Ближе всего:", "Думаю про"],
    weight:     ["По насыщенности:", "Толщина —", "Хочется"],
    tracking:   ["По расстоянию между буквами:", "Трекинг —", "Пусть будет"],
    custom:     ["Насчёт букв:", "По доработке:", "Думаю, нужно"],
    avoid:      ["Точно не хочу:", "Избегайте, пожалуйста:", "Не подходит:"]
  };
  return rand(leads[key] || ["Отвечу так:"]);
}

/* ============================================================
   ФИНАЛЬНЫЙ БРИФ
   ============================================================ */
function val(key) {
  const a = answered[key];
  if (!a) return "—";
  return a.join(", ");
}

function buildBrief() {
  clearChips();
  elHint.textContent = "Бриф сформирован";

  // финальная реплика заказчика
  clientSays("Отлично, этого достаточно. Жду готовый бриф и концепцию!", company.name, 450)
    .then(renderBriefCard);
}

function renderBriefCard() {
  const c = company;
  const card = document.createElement("div");
  card.className = "brief";

  const specs = [
    ["Характер", val("character")],
    ["Тип шрифта", val("fontType")],
    ["Стиль", val("style")],
    ["Трекинг", val("tracking")],
    ["Кастомизация", val("custom")]
  ];

  const specsHtml = specs.map(([l, v], i) => {
    const wide = (specs.length % 2 === 1 && i === specs.length - 1) ? " spec--wide" : "";
    return `<div class="spec${wide}"><p class="spec__label">${l}</p><div class="spec__value">${v}</div></div>`;
  }).join("");

  card.innerHTML = `
    <div class="brief__head">
      <p class="brief__eyebrow">Типографический бриф</p>
      <h2 class="brief__company">«${c.name}»</h2>
      <p class="brief__sphere">Сфера: ${c.sphere}</p>
      <p class="brief__desc">${c.desc}</p>
    </div>

    <div class="brief__grid">
      ${specsHtml}
      <div class="spec spec--wide">
        <p class="spec__label">Ограничения</p>
        <div class="spec__value">${val("avoid")}</div>
      </div>
    </div>

    <div class="concept">
      <p class="concept__title">Концепция wordmark-логотипа</p>
      <div class="concept__item">
        <span class="concept__k">Идея</span>
        <span class="concept__v">${c.concept.idea}</span>
      </div>
      <div class="concept__item">
        <span class="concept__k">Рекомендации</span>
        <span class="concept__v">${c.concept.recommend}</span>
      </div>
      <div class="concept__item">
        <span class="concept__k">Какие буквы можно изменить</span>
        <span class="concept__v">${c.concept.letters}</span>
      </div>
      <div class="concept__item">
        <span class="concept__k">Типографический приём</span>
        <span class="concept__v">${c.concept.technique}</span>
      </div>
    </div>

    <div class="task">
      <h3 class="task__title">Финальное задание</h3>
      <p class="task__lead">Создайте 3 варианта текстового логотипа «${c.name}» в CorelDRAW.</p>
      <ul class="task__list">
        <li>использовать только типографику — без иконок, изображений и символов;</li>
        <li>подобрать подходящий шрифт под характер и стиль из брифа;</li>
        <li>преобразовать текст в кривые;</li>
        <li>настроить кернинг и трекинг вручную;</li>
        <li>изменить минимум одну букву;</li>
        <li>создать уникальное типографическое решение;</li>
        <li>проверить логотип в чёрно-белом варианте и на тёмном фоне.</li>
      </ul>
    </div>
  `;

  const row = document.createElement("div");
  row.className = "row";
  row.style.justifyContent = "stretch";
  row.appendChild(card);
  elMessages.appendChild(row);
  scrollDown();

  // действия после брифа
  clearChips();
  elHint.textContent = "Бриф готов — можно начать заново";
  makeChip("Начать новый бриф", resetAll, "primary");
}

/* ============================================================
   СБРОС
   ============================================================ */
function resetAll() {
  company = null;
  answered = {};
  started = false;
  elMessages.innerHTML = "";
  elProgWrap.hidden = true;
  elProgFill.style.width = "0%";
  elProgCount.textContent = "0 / 6";
  bootIntro();
}

/* ---------- Запуск ---------- */
document.addEventListener("DOMContentLoaded", bootIntro);
